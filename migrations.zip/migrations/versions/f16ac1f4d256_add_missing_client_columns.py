"""add missing client columns

Revision ID: f16ac1f4d256
Revises: 0b6d517c78fd
Create Date: 2026-07-12 00:06:21.938053

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'f16ac1f4d256'
down_revision = '0b6d517c78fd'
branch_labels = None
depends_on = None


from alembic import op
import sqlalchemy as sa

def upgrade():
    with op.batch_alter_table("clients") as batch_op:

        batch_op.add_column(
            sa.Column("client_reference", sa.String(50), nullable=True)
        )

        batch_op.add_column(
            sa.Column("pipeline_stage", sa.String(50), nullable=True)
        )

        batch_op.create_index(
            "ix_clients_client_reference",
            ["client_reference"],
            unique=True
        )

        batch_op.create_index(
            "ix_clients_pipeline_stage",
            ["pipeline_stage"],
            unique=False
        )


def downgrade():
    with op.batch_alter_table("clients") as batch_op:
        batch_op.drop_index("ix_clients_pipeline_stage")
        batch_op.drop_index("ix_clients_client_reference")
        batch_op.drop_column("pipeline_stage")
        batch_op.drop_column("client_reference")


def downgrade():
    pass
